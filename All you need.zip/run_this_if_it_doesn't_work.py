import os
os.system("pip install openpyxl")